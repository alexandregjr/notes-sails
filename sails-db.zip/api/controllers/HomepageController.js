/**
 * HomepageController
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */

module.exports = {
  

    /**
     * `HomepageController.addText()`
     */
    addText: async function (req, res) {
        console.log(req.body)

        let msg = "adicionado pelo server: " + req.body.message

        try {
            await Note.create({description: msg})
        } catch (err) {
            return res.status(500).send(msg)
        }
        
        
        return res.send(msg);

    },

    /**
     * `HomepageController.validateNote()`
     */
    validateNote: async function (req, res) {
        console.log(req.body)
        let { name, type } = req.body
        if (!name)
            return res.json({valid: false})
        if (!type)
            return res.json({valid: false})
        return res.json({valid: true})
    },

    /**
     * `HomepageController.getNotes()`
     */
    getNotes: async function (req, res) {
        let notes = await Note.find()
        
        res.send(notes)

    },

    /**
     * `HomepageController.removeItem()`
     */
    removeItem: async function (req, res) {
        console.log(req.body)
        let notes = await Note.destroyOne({
            description: req.body.msg
        })

        res.ok()
    },
};

